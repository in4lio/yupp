
#ops
print 'Hello yupp!'

pq = None
r = 0
q = 2

___cond = pq
while True:
    if ___cond is None:
        r = 100500
        break

    if ___cond == 3:
        r += 30;

    if ___cond == ( 2 ):
        r += 20;

    if ___cond == ( q ):
        r += 1;
    break

print r
